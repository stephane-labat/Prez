---
title: "Charts"
date: 2017-03-02T12:00:00-05:00
---
Charts are fun.
