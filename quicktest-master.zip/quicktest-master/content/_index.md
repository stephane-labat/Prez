---
title: "Leagify's quick test"
featured_image: '/images/chartBanner01.png'
description: "The last theme you'll ever need. Maybe."
---
Welcome to the quick test blog.
