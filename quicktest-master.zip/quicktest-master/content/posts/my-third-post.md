---
title: "My Third Post"
date: 2017-09-10T21:43:49-05:00
type: category01
---

Hello again

<!--more-->

This is a post with a type.
