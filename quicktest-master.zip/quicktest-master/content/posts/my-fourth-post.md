---
title: "My Fourth Post"
date: 2017-09-10T21:46:35-05:00
type: category01
---

Hello, etc.

<!--more-->

This is also a post with a type.
