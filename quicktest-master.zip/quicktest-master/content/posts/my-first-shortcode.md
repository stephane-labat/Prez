---
title: "My First Shortcode"
date: 2017-09-11T19:56:29-05:00
---

Hello, shortcodes!
<!--more-->

Tweet(s) :
{{< tweet 845330563938598912 >}}

{{< tweet 684947849197391872 >}}

Youtube :
{{< youtube 9l5C8cGMueY >}}


Speakerdeck :
{{< speakerdeck 5a6e972b555e466ab9db6f96cfac65c4 >}}

Image embed:

{{< figure src="/quicktest/images/chartBanner02.png" title="Chart Banner" >}}
